# Universe™ v1.0

A Termux-native Potentia system that delivers the Uniiverse Secrets and wisdom every hour.

## 🔧 Install

```bash
pkg install git python termux-api
git clone https://github.com/latenspotentia/universe
cd universe
bash install.sh
