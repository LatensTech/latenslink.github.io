#!/data/data/com.termux/files/usr/bin/bash

echo "🔧 Installing Universe™..."

pkg update -y
pkg upgrade -y
pkg install python termux-api -y

# Setup cron job
SCRIPT_PATH=$(realpath secrets.py)
(crontab -l 2>/dev/null; echo "0 * * * * python3 $SCRIPT_PATH") | crontab -

echo "✅ Universe™ installed."
echo "🧠 You’ll start receiving encrypted wisdom every hour."
