import os

def list_tracks(directory="pfiles"):
    if not os.path.exists(directory):
        print(f"📂 Directory '{directory}' not found.")
        return

    files = [f for f in os.listdir(directory) if f.lower().endswith(".mp3")]
    if not files:
        print("🎶 No tracks found in pfiles/")
        return

    print("🎵 Available Tracks:\n")
    for idx, file in enumerate(files, start=1):
        print(f"[{idx}] {file}")

if __name__ == "__main__":
    list_tracks()
