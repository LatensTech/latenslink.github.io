import os
import subprocess
import datetime
import json

# Directories
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FILES_DIR = os.path.join(BASE_DIR, "pfiles")
LOGS_DIR = os.path.join(BASE_DIR, "plogs")

# Ensure dirs exist
os.makedirs(FILES_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

def log(msg):
    """Write events to plogs/"""
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(os.path.join(LOGS_DIR, "pmusic.log"), "a") as f:
        f.write(f"[{ts}] {msg}\n")

def download_single(query):
    """Download a single song (first search result)."""
    print(f"🔍 Searching for: {query}")
    cmd = [
        "yt-dlp", f"ytsearch1:{query}",
        "--extract-audio", "--audio-format", "mp3",
        "-o", os.path.join(FILES_DIR, "%(title)s.%(ext)s"),
        "--no-playlist"
    ]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print("✅ Download finished ,Track added to Playlist.")
    log(f"Single download: {query}")

def search_and_select(query, limit=None):
    """Dynamic search + select from results (no dedup, capped at limit)."""
    if not limit:  
        limit = 5  # fallback default
    limit = min(limit, 15)  # hard safety cap

    cmd = [
        "yt-dlp", f"ytsearch{limit}:{query}",
        "--skip-download", "--dump-json"
    ]
    print(f"🔍 Searching for: {query} (limit {limit})...")

    videos = []
    try:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
        for line in process.stdout:
            if len(videos) >= limit:
                break  # stop once limit reached
            line = line.strip()
            if not line:
                continue
            try:
                v = json.loads(line)
                videos.append(v)
                print(f"[{len(videos)}] {v['title']}")
            except json.JSONDecodeError:
                continue
        process.wait(timeout=20)
    except subprocess.TimeoutExpired:
        print("⚠️ Search timed out, showing partial results...")

    if not videos:
        print("❌ No results found.")
        return

    choice = input("\nSelect tracks (e.g. 1,3,5 or 'all'): ").strip()
    if choice.lower() == "all":
        picks = range(1, len(videos) + 1)
    else:
        picks = [int(x) for x in choice.split(",") if x.isdigit()]

    for i in picks:
        if 1 <= i <= len(videos):
            v = videos[i - 1]
            print(f"⬇️  Downloading track {i}: {v['title']} ...")
            out_template = os.path.join(FILES_DIR, "%(title)s.%(ext)s")
            cmd = [
                "yt-dlp", v["webpage_url"],
                "--extract-audio", "--audio-format", "mp3",
                "-o", out_template,
                "--no-playlist"
            ]
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"✅ Finished & Added to Playlist: {v['title']}")
            log(f"Downloaded: {v['title']}")
        else:
            print(f"⚠️ Skipping invalid choice: {i}")

def main():
    print("\n🎵 Search and Download Music 🎵")
    print("1) Single Song")
    print("2) Dynamic Search")
    option = input("Choose option: ").strip()

    if option == "1":
        song = input("Enter song name + artist: ")
        download_single(song)
    elif option == "2":
        mode = input("Search by (artist/song): ").strip().lower()
        query = input(f"Enter {mode} name: ")
        try:
            limit = int(input("How many results to fetch? (default 5): ") or 5)
        except ValueError:
            limit = 5
        search_and_select(query, limit)
    else:
        print("❌ Invalid option.")

if __name__ == "__main__":
    main()
