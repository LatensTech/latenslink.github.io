#!/usr/bin/env python3
import subprocess
import sys
import os

# Color styling for the menu
def banner():
    print("\n" + "="*40)
    print("🎵 Welcome to Pmusic 🎵")
    print("="*40)

def main_menu():
    while True:
        banner()
        print("1) Search & Download Music")
        print("2) Play Music")
        print("3) View Playlist")
        print("0) Exit")
        choice = input("\nChoose option: ").strip()

        if choice == "1":
            run_script("pmv3.py")
        elif choice == "2":
            run_script("plyv4.py")
        elif choice == "3":
            run_script("playlist.py")
        elif choice == "0":
            print("👋 Good Vibes Always. Bye!")
            sys.exit(0)
        else:
            print("⚠️ Invalid choice, try again.")

def run_script(script_name):
    """Launch sub-scripts cleanly"""
    script_path = os.path.join(os.path.dirname(__file__), script_name)
    try:
        subprocess.run([sys.executable, script_path])
    except Exception as e:
        print(f"❌ Error running {script_name}: {e}")

if __name__ == "__main__":
    main_menu()
