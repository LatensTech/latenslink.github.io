#!/data/data/com.termux/files/usr/bin/bash

echo "🎶 Bootstrapping Pmusic Protocol..."
sleep 2

# ✅ Update system
pkg update -y
pkg install python termux-api cronie mpv ffmpeg -y

# 📦 Check Python deps
if ! python3 -c "import requests" &> /dev/null; then
    echo "📦 Installing Python requests module..."
    pip install requests
    pip install --upgrade yt-dlp
else
    echo "✅ Python requests module already installed."
fi

echo "$(date) - Checked Python dependencies" >> ~/potentia/logs/potentia.log
sleep 2

echo "📁 Creating base directories... ~/potentia/drops/pmusic"
sleep 1

# 📁 Create base directories
mkdir -p ~/potentia/drops
mkdir -p ~/potentia/config
mkdir -p ~/potentia/logs

# 📦 Move current folder (drop) into pmusic drop folder
CURRENT_DIR=$(pwd)
DROP_DEST=~/potentia/drops/pmusic
rm -rf "$DROP_DEST"
mkdir -p "$DROP_DEST"
cp -r "$CURRENT_DIR"/* "$DROP_DEST"

# 📜 Ensure logs exist
touch "$DROP_DEST/pmusic.log"
touch ~/potentia/logs/potentia.log

echo "🔗 Syncing Pmusic With Potentia Grid..."
sleep 1

# ⚙️ No cron job needed unless you want scheduled runs
# (skip crontab for now)

# ⚙️ Create config file if missing
CONFIG_FILE=~/potentia/config/potentia.env
if [ ! -f "$CONFIG_FILE" ]; then
    echo "# Potentia Config" > "$CONFIG_FILE"
    echo "PMUSIC_ENABLED=true" >> "$CONFIG_FILE"
    echo "INSTALL_DATE=$(date)" >> "$CONFIG_FILE"
else
    sed -i "s/PMUSIC_ENABLED=.*/PMUSIC_ENABLED=true/" "$CONFIG_FILE"
fi

# 🧙 Add shell alias for pmusic
SHELL_NAME=$(basename "$SHELL")
if [ "$SHELL_NAME" = "zsh" ]; then
    PROFILE_FILE=~/.zshrc
else
    PROFILE_FILE=~/.bashrc
fi

ALIAS_CMD='alias pmusic="python3 ~/potentia/drops/pmusic/Pmusic.py"'
grep -qxF "$ALIAS_CMD" "$PROFILE_FILE" || echo "$ALIAS_CMD" >> "$PROFILE_FILE"

ALIAS_ENTER='alias drops="cd ~/potentia/drops"'
grep -qxF "$ALIAS_ENTER" "$PROFILE_FILE" || echo "$ALIAS_ENTER" >> "$PROFILE_FILE"

# 🔁 Reload shell profile to activate alias
source "$PROFILE_FILE"

echo "✅ Pmusic installed and synced with Potentia Protocol."
echo "🎵 Type pmusic to launch the menu."
echo "✒️ Edit the drop by typing drops"
sleep 2

echo "🚀 Initiating First Launch..."
python3 "$DROP_DEST/Pmusic.py"
