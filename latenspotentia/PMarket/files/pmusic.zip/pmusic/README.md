# 🎶 Pmusic  

**Pmusic** is a lightweight, terminal-based music system that lets you **search, download, and play tracks** — all from your command line.  
Designed for speed, simplicity, and hack-style vibes, it’s built to be portable, scriptable, and fun.  

---

## ✨ Features  

- 🔍 **Search & Download** music instantly via YouTube (`yt-dlp` powered).  
- 🎧 **Play seamlessly** with `mpv` — continuous playback with simple controls.  
- 📂 **Auto-organized library** — all downloads land in the `pfiles/` folder.  
- 📜 **Dynamic playlist display** — browse, select, or play *all* tracks at once.  
- ⏯️ **Player controls**:  
  - `[p]` pause/resume  
  - `[n]` next track  
  - `[s]` stop playback  
  - `[q]` quit player  
- 🛠️ **Extendable menu system** — ready for more modules/features in future drops.  

---

## 🚀 Installation  

Clone the repo:  
```bash
git clone https://github.com/LatensTech/Pmusic.git
cd Pmusic
bash install.sh
