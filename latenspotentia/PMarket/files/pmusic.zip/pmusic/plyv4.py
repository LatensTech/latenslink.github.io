import os
import subprocess
import signal
import sys
import select

MUSIC_DIR = "pfiles"

def list_tracks():
    return sorted([f for f in os.listdir(MUSIC_DIR) if f.endswith(".mp3")])

def play_tracks(tracks):
    current_proc = None

    for track in tracks:
        print(f"\n🎶 Now playing: {track}")
        track_path = os.path.join(MUSIC_DIR, track)

        # Launch mpv
        current_proc = subprocess.Popen(
            ["mpv", "--quiet", "--no-terminal", track_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        # Print controls ONCE per track
        print("Controls: [p]ause/resume | [n]ext | [s]top | [q]uit player")

        while True:
            if current_proc.poll() is not None:
                # Track finished naturally, move to next one
                break

            try:
                i, _, _ = select.select([sys.stdin], [], [], 1)  # wait max 1s
                if not i:
                    continue  # no input, just keep looping

                cmd = sys.stdin.readline().strip().lower()

            except KeyboardInterrupt:
                cmd = "q"

            if cmd == "p":
                if current_proc.poll() is None:
                    os.kill(current_proc.pid, signal.SIGSTOP)
                    print("⏸ Paused. Press Enter to resume.")
                    input()
                    os.kill(current_proc.pid, signal.SIGCONT)
                    print("▶️ Resumed.")
            elif cmd == "n":
                if current_proc.poll() is None:
                    current_proc.terminate()
                    current_proc.wait()
                break  # go next
            elif cmd == "s":
                if current_proc.poll() is None:
                    current_proc.terminate()
                    current_proc.wait()
                print("🛑 Stopped.")
                return
            elif cmd == "q":
                if current_proc.poll() is None:
                    current_proc.terminate()
                    current_proc.wait()
                return
            elif cmd:
                print("⚠️ Unknown command.")

def main():
    tracks = list_tracks()
    if not tracks:
        print("No music found in pfiles/")
        return

    print("🎵 Available tracks:")
    for i, t in enumerate(tracks, 1):
        print(f"[{i}] {t}")

    choice = input("\nSelect track(s) (e.g. 1,3,5 or 'all'): ").strip()
    if choice == "all":
        selected = tracks
    else:
        try:
            indexes = [int(x) for x in choice.split(",")]
            selected = [tracks[i-1] for i in indexes if 0 < i <= len(tracks)]
        except ValueError:
            print("⚠️ Invalid choice.")
            return

    play_tracks(selected)

if __name__ == "__main__":
    main()
